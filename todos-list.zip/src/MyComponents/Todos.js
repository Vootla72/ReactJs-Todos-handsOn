import React from 'react';
import { TodoItem } from "../MyComponents/TodoItem";
export const Todos = (props) => {
  return <div className='container'>

    <h3 className=" my-3"> Todos List</h3>
    {props.todos.map((todo2)=>{return(
    
    /* <h3>This</h3> */
      
      <TodoItem todo2={todo2} key={todo2.snoo} onDelete={props.onDelete}/>
      )
      
      })}
   
  </div>
};
