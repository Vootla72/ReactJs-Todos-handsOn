import './App.css';
import Header from './MyComponents/Header';
import { Todos } from './MyComponents/Todos';
import { Footer } from './MyComponents/Footer';
import { AddTodo } from "./MyComponents/AddTodo";
import React, { useState } from 'react';

function App() {
  const onDelete = (todo2) => {
    console.log('I am ondelete', todo2);
    setTodos(
      todos.filter((e) => {
        return e !== todo2;
      })
    );
  };
  const [todos, setTodos] = useState([
    {
      sno: 1,
      title: 'Go to the Market',
      desc: 'You need to go to the market to get this job done',
    },
    {
      sno: 2,
      title: 'Go to the Mall',
      desc: 'You need to go to the market to get this job done2',
    },
    {
      sno: 1,
      title: 'Go to the Ghat',
      desc: 'You need to go to the market to get this job done3',
    },
  ]);

  return (
    <>
      <Header title='My Todos-List' searchBar={false} />
      <AddTodo/>
      <Todos todos={todos} onDelete={onDelete} />
      <Footer />
    </>
  );
}
export default App;
